-- Mi aventurero (usuario: alumno / contraseña: Alumno2026)
-- Hash generado con: php -r "echo password_hash('Alumno2026', PASSWORD_DEFAULT);"
INSERT INTO aventureros (usuario, nombre, clase, password_hash) VALUES
('alumno', 'Alumno DAW', 'Programador', '$2y$10$Y7urDHmoCivBJ5VwdE7U0OhGYZpasXcplRAUIHHFZgTeiOncE.E.O');
