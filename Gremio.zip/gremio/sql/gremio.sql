-- El Gremio de Aventureros · esquema y datos de prueba
-- Importar en la base de datos dbname desde phpMyAdmin.

CREATE TABLE IF NOT EXISTS aventureros (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(30) NOT NULL UNIQUE,
  nombre VARCHAR(60) NOT NULL,
  clase VARCHAR(30) NOT NULL,
  password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO aventureros (usuario, nombre, clase, password_hash) VALUES
('brunhilda', 'Brunhilda', 'Guerrera', '$2y$10$HdWBRE/hXitmUSyEbNS/OexdmatlYFDj93c8YASX/q1S/bWdo6c2u'),
('aldric', 'Aldric', 'Mago', '$2y$10$dbtF5ps5vJEC7RxDIIc.NulLriiDG8b9roDUODzYUKXW.lMixpi0q'),
('vex', 'Vex', 'Pícaro', '$2y$10$pKpFx7owlNzW8nw/n1rACOKHXykvAUMlRsQqFnwGXL73WIsAqeU4K');
