# MEMORIA · El Gremio de Aventureros (UD3-UD5)

**Código de alumno:** `[RELLENAR]`

## 1. Qué he hecho
- **Parte 1 (UD3):** `etiquetaRango` y `claseRango` con `match` (varios valores por brazo), `formatearOro` con `number_format`, y el tablón con `foreach`, singular/plural de días y todo texto escapado con `e()`.
- **Parte 2 (UD4):** filtros por GET validados con `filter_var(FILTER_VALIDATE_INT)`, `filtrarMisiones` con `foreach`, `buscarMision`, `totalRecompensa` (reutiliza `buscarMision`). Aceptar/abandonar por POST con patrón Post/Redirect/Get.
- **Parte 3 (UD5):** login contra MySQL con consulta preparada (`:usuario`) y `password_verify`; sesión con `session_regenerate_id(true)`; `requiereLogin()` en tablón, zurrón y preferencias; `cerrarSesion()` completo; cookies de tema y de usuario recordado.

## 2. Decisiones de seguridad
- Ninguna consulta SQL concatena variables; el usuario `' OR '1'='1` no encuentra fila y recibe el mismo mensaje genérico.
- Las contraseñas solo existen como hash (`password_hash`); la cookie solo guarda el nombre de usuario.
- Mismo mensaje si falla el usuario o la contraseña (no revela qué usuarios existen).
- Los errores de BD van a `error_log`; el usuario ve un mensaje genérico.
- Cookies con `path=/`, `httponly` y `samesite=Lax` (array de opciones).
- La cookie `gremio_tema` se valida contra la lista `['claro','oscuro']`; cualquier otro valor se trata como «claro» y nunca se imprime.

## 3. ¿Por qué el tema y el usuario sobreviven al cierre de sesión y el zurrón no?
El zurrón está en `$_SESSION`: memoria **del servidor** ligada a la cookie de sesión. Al cerrar sesión se vacía `$_SESSION`, se caduca la cookie `PHPSESSID` y se llama a `session_destroy()`, así que esos datos dejan de existir. El tema y el usuario recordado están en **cookies propias del navegador con fecha de caducidad** (1 año y 30 días): `cerrarSesion()` solo elimina la cookie de sesión, no esas, y el navegador las sigue enviando. Es información de preferencia, no de estado de la sesión.

## 4. Pruebas realizadas (sección 7 del enunciado)
| # | Resultado |
|---|-----------|
| 1 | Sin sesión, `tablon.php` redirige a `login.php?motivo=privado` y avisa «solo para miembros» |
| 2 | Clave incorrecta → «Usuario o contraseña incorrectos.» |
| 3 | `' OR '1'='1` → mismo mensaje, no entra |
| 4 | Login con «Recordar» → tras salir, el usuario aparece relleno |
| 5 | Misma misión dos veces → aviso, sin duplicar; F5 no reenvía (PRG) |
| 6 | Cada recarga del tablón sube el contador |
| 7 | Cambiar tema y salir → el tema se mantiene, el zurrón se vacía |
| 8 | Cookie `gremio_tema` manipulada → tema claro, sin pintar el texto |
| 9 | `tablon.php?rango=Z&oro=hola` → 10 misiones sin errores |
| 10 | Entrar con mi aventurero (`sql/mi_aventurero.sql`) → funciona |

Comprobaciones UD3/UD4: 10 tarjetas; rango B y oro mínimo 500 → 2 misiones; «Bandidos del desfiladero» + «El dragón de Obsidiana» → 5.650 mo.

## 5. Uso de IA
`[RELLENAR: indicar si se ha usado el NotebookLM del profesor y para qué]`
