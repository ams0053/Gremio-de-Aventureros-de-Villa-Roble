<?php
require __DIR__ . '/inc/sesion.php';
cerrarSesion();
header('Location: login.php?motivo=salio');
exit;
