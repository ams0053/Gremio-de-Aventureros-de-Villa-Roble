<?php
declare(strict_types=1);

/**
 * Conexión PDO. Ajusta host/usuario/clave a tu docker-lamp si es necesario.
 * Se pueden sobrescribir con variables de entorno (GREMIO_DSN, GREMIO_USER, GREMIO_PASS).
 */
function conectar(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $dsn  = getenv('GREMIO_DSN')  ?: 'mysql:host=db;dbname=dbname;charset=utf8mb4';
    $user = getenv('GREMIO_USER') ?: 'dbuser';
    $pass = getenv('GREMIO_PASS') ?: 'dbpass';

    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    return $pdo;
}
