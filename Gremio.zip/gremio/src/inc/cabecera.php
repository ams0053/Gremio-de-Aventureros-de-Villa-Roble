<?php
/** Cabecera común. Requiere $titulo y que sesion.php/funciones.php ya estén cargados. */
$aventurero = aventureroActual();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($titulo ?? 'Gremio') ?> · Gremio de Aventureros</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body class="tema-<?= e(temaActual()) ?>">
<header class="barra">
    <h1>⚔️ Gremio de Aventureros</h1>
    <nav>
        <?php if ($aventurero !== null): ?>
            <a href="tablon.php">Tablón</a>
            <a href="zurron.php">Zurrón (<?= count($_SESSION['zurron'] ?? []) ?>)</a>
            <a href="preferencias.php">Preferencias</a>
            <span class="quien"><?= e($aventurero['nombre']) ?> · <?= e($aventurero['clase']) ?></span>
            <a href="logout.php">Salir</a>
        <?php else: ?>
            <span class="quien">Invitado</span>
            <a href="login.php">Entrar</a>
        <?php endif; ?>
    </nav>
</header>
<main>
<?php foreach (obtenerFlash() as $f): ?>
    <p class="flash <?= e($f['tipo']) ?>"><?= e($f['mensaje']) ?></p>
<?php endforeach; ?>
