<?php
declare(strict_types=1);

const COOKIE_TEMA    = 'gremio_tema';
const COOKIE_USUARIO = 'gremio_usuario';
const TEMAS          = ['claro', 'oscuro'];

/** Opciones comunes de todas las cookies: path /, httponly, SameSite Lax. */
function opcionesCookie(int $segundos): array
{
    return [
        'expires'  => time() + $segundos,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ];
}

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/* ---------- Mensajes flash ---------- */

function flash(string $mensaje, string $tipo = 'info'): void
{
    $_SESSION['flash'][] = ['mensaje' => $mensaje, 'tipo' => $tipo];
}

function obtenerFlash(): array
{
    $mensajes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $mensajes;
}

/* ---------- Autenticación ---------- */

function aventureroActual(): ?array
{
    return isset($_SESSION['aventurero']) && is_array($_SESSION['aventurero'])
        ? $_SESSION['aventurero']
        : null;
}

function requiereLogin(): void
{
    if (aventureroActual() === null) {
        header('Location: login.php?motivo=privado');
        exit;
    }
}

function cerrarSesion(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }
    session_destroy();
}

/* ---------- Cookies: tema y usuario recordado ---------- */

/** Lee la cookie del tema; cualquier valor manipulado vuelve a «claro». */
function temaActual(): string
{
    $tema = $_COOKIE[COOKIE_TEMA] ?? 'claro';
    return (is_string($tema) && in_array($tema, TEMAS, true)) ? $tema : 'claro';
}

function guardarTema(string $tema): void
{
    if (!in_array($tema, TEMAS, true)) {
        $tema = 'claro';
    }
    setcookie(COOKIE_TEMA, $tema, opcionesCookie(365 * 24 * 3600));
    $_COOKIE[COOKIE_TEMA] = $tema;
}

function usuarioRecordado(): string
{
    $u = $_COOKIE[COOKIE_USUARIO] ?? '';
    return is_string($u) ? mb_substr($u, 0, 30) : '';
}

function recordarUsuario(string $usuario): void
{
    setcookie(COOKIE_USUARIO, $usuario, opcionesCookie(30 * 24 * 3600));
    $_COOKIE[COOKIE_USUARIO] = $usuario;
}

function olvidarUsuario(): void
{
    setcookie(COOKIE_USUARIO, '', opcionesCookie(-3600));
    unset($_COOKIE[COOKIE_USUARIO]);
}
