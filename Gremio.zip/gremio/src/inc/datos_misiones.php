<?php
declare(strict_types=1);

/** Misiones del tablón (en la UD9 pasarán a MySQL). */
function obtenerMisiones(): array
{
    return [
        ['id' => 1,  'titulo' => 'Ratas en la bodega',        'rango' => 'E', 'oro' => 50,   'dias' => 1, 'descripcion' => 'La taberna tiene visitantes con cola y bigotes.'],
        ['id' => 2,  'titulo' => 'Hierbas lunares',           'rango' => 'E', 'oro' => 80,   'dias' => 2, 'descripcion' => 'Recoge tres manojos antes de la luna llena.'],
        ['id' => 3,  'titulo' => 'Escolta de la caravana',    'rango' => 'D', 'oro' => 200,  'dias' => 3, 'descripcion' => 'Acompaña a los mercaderes hasta Puerto Alba.'],
        ['id' => 4,  'titulo' => 'Lobos del Bosque Umbrío',   'rango' => 'D', 'oro' => 350,  'dias' => 2, 'descripcion' => 'Una manada acecha a los leñadores.'],
        ['id' => 5,  'titulo' => 'Bandidos del desfiladero',  'rango' => 'C', 'oro' => 650,  'dias' => 3, 'descripcion' => 'Despeja el paso de montaña de salteadores.'],
        ['id' => 6,  'titulo' => 'Mapa robado',               'rango' => 'B', 'oro' => 300,  'dias' => 1, 'descripcion' => 'Recupera el mapa del maestre antes del alba.'],
        ['id' => 7,  'titulo' => 'El puente del trol',        'rango' => 'B', 'oro' => 900,  'dias' => 4, 'descripcion' => 'Un trol cobra peaje y no admite regateos.'],
        ['id' => 8,  'titulo' => 'El ladrón de la torre',     'rango' => 'B', 'oro' => 1200, 'dias' => 5, 'descripcion' => 'Alguien se ha llevado el orbe del archimago.'],
        ['id' => 9,  'titulo' => 'El hechicero errante',      'rango' => 'A', 'oro' => 2500, 'dias' => 7, 'descripcion' => 'Sus conjuros están convirtiendo aldeas en piedra.'],
        ['id' => 10, 'titulo' => 'El dragón de Obsidiana',    'rango' => 'S', 'oro' => 5000, 'dias' => 10, 'descripcion' => 'La leyenda duerme bajo el volcán. Hoy despierta.'],
    ];
}
