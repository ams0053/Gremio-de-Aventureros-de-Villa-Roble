<?php
declare(strict_types=1);

const RANGOS = ['E', 'D', 'C', 'B', 'A', 'S'];

/** Escapa texto para HTML. */
function e(mixed $texto): string
{
    return htmlspecialchars((string) $texto, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/* ---------- Parte 1 · UD3 ---------- */

function etiquetaRango(string $rango): string
{
    return match ($rango) {
        'E' => 'Novato',
        'D' => 'Aprendiz',
        'C' => 'Veterano',
        'B' => 'Experto',
        'A' => 'Élite',
        'S' => 'Leyenda',
        default => 'Desconocido',
    };
}

function claseRango(string $rango): string
{
    return match ($rango) {
        'E', 'D' => 'facil',
        'C', 'B' => 'media',
        'A', 'S' => 'dificil',
        default  => 'facil',
    };
}

function formatearOro(int $oro): string
{
    return number_format($oro, 0, ',', '.') . ' mo';
}

function formatearDias(int $dias): string
{
    return $dias . ($dias === 1 ? ' día' : ' días');
}

/* ---------- Parte 2 · UD4 ---------- */

function leerRangoFiltro(array $datos): ?string
{
    $rango = $datos['rango'] ?? null;
    return (is_string($rango) && in_array($rango, RANGOS, true)) ? $rango : null;
}

function leerOroMinimo(array $datos): int
{
    $oro = filter_var($datos['oro'] ?? null, FILTER_VALIDATE_INT, [
        'options' => ['min_range' => 0, 'max_range' => 10000],
    ]);
    return $oro === false ? 0 : $oro;
}

function filtrarMisiones(array $misiones, ?string $rango, int $oroMinimo): array
{
    $resultado = [];
    foreach ($misiones as $mision) {
        if ($rango !== null && $mision['rango'] !== $rango) {
            continue;
        }
        if ($mision['oro'] < $oroMinimo) {
            continue;
        }
        $resultado[] = $mision;
    }
    return $resultado;
}

function buscarMision(array $misiones, int $id): ?array
{
    foreach ($misiones as $mision) {
        if ($mision['id'] === $id) {
            return $mision;
        }
    }
    return null;
}

/** Suma la recompensa de los ids del zurrón reutilizando buscarMision(). */
function totalRecompensa(array $idsZurron, array $misiones): int
{
    $total = 0;
    foreach ($idsZurron as $id) {
        $mision = buscarMision($misiones, (int) $id);
        if ($mision !== null) {
            $total += $mision['oro'];
        }
    }
    return $total;
}

/** Query string con los filtros vigentes (solo valores ya validados). */
function consultaFiltros(?string $rango, int $oroMinimo): string
{
    $q = [];
    if ($rango !== null) {
        $q['rango'] = $rango;
    }
    if ($oroMinimo > 0) {
        $q['oro'] = $oroMinimo;
    }
    return $q ? '?' . http_build_query($q) : '';
}

/* ---------- Parte 3 · UD5 ---------- */

/**
 * Devuelve el aventurero (sin hash) o null. Consulta preparada + password_verify.
 */
function autenticar(PDO $pdo, string $usuario, string $clave): ?array
{
    $stmt = $pdo->prepare(
        'SELECT id, usuario, nombre, clase, password_hash FROM aventureros WHERE usuario = :usuario'
    );
    $stmt->execute([':usuario' => $usuario]);
    $fila = $stmt->fetch();

    if ($fila === false) {
        // Verificación ficticia: iguala el tiempo de respuesta con usuario inexistente.
        password_verify($clave, '$2y$10$usesomesillystringforsaltuOq0g8Y1y1o1y1o1y1o1y1o1y1o1y');
        return null;
    }
    if (!password_verify($clave, $fila['password_hash'])) {
        return null;
    }
    unset($fila['password_hash']);
    return $fila;
}
