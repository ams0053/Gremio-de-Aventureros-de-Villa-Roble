<?php
declare(strict_types=1);
require __DIR__ . '/inc/sesion.php';
require __DIR__ . '/inc/funciones.php';

requiereLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tema = $_POST['tema'] ?? 'claro';
    guardarTema(is_string($tema) ? $tema : 'claro');
    flash('Tema guardado.', 'ok');
    header('Location: preferencias.php');
    exit;
}

$tema = temaActual();
$titulo = 'Preferencias';
require __DIR__ . '/inc/cabecera.php';
?>
<h2>Preferencias</h2>
<form method="post" action="preferencias.php" class="formulario">
    <fieldset>
        <legend>Tema visual</legend>
        <?php foreach (TEMAS as $t): ?>
            <label class="check">
                <input type="radio" name="tema" value="<?= e($t) ?>" <?= $tema === $t ? 'checked' : '' ?>>
                <?= e(ucfirst($t)) ?>
            </label>
        <?php endforeach; ?>
    </fieldset>
    <button type="submit">Guardar</button>
</form>
<?php require __DIR__ . '/inc/pie.php'; ?>
