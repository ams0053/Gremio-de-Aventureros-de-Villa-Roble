<?php
declare(strict_types=1);
require __DIR__ . '/inc/sesion.php';
require __DIR__ . '/inc/funciones.php';
require __DIR__ . '/inc/datos_misiones.php';

requiereLogin();
$misiones = obtenerMisiones();

/* Aceptar misión: POST -> flash -> redirect (Post/Redirect/Get). */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'aceptar') {
    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
    $mision = $id === false ? null : buscarMision($misiones, $id);
    $zurron = $_SESSION['zurron'] ?? [];

    if ($mision === null) {
        flash('Esa misión no existe.', 'error');
    } elseif (in_array($mision['id'], $zurron, true)) {
        flash('Ya llevas «' . $mision['titulo'] . '» en el zurrón.', 'aviso');
    } else {
        $_SESSION['zurron'][] = $mision['id'];
        flash('Misión aceptada: ' . $mision['titulo'] . '.', 'ok');
    }
    header('Location: tablon.php' . consultaFiltros(leerRangoFiltro($_POST), leerOroMinimo($_POST)));
    exit;
}

$rango    = leerRangoFiltro($_GET);
$oroMin   = leerOroMinimo($_GET);
$visibles = filtrarMisiones($misiones, $rango, $oroMin);

$_SESSION['visitas'] = ($_SESSION['visitas'] ?? 0) + 1;
$enZurron = $_SESSION['zurron'] ?? [];

$titulo = 'Tablón';
require __DIR__ . '/inc/cabecera.php';
?>
<h2>Tablón de misiones</h2>
<p class="estado">
    Visitas al tablón en esta sesión: <strong><?= (int) $_SESSION['visitas'] ?></strong> ·
    Entraste a las <strong><?= e($_SESSION['hora_entrada'] ?? '--:--:--') ?></strong>
</p>

<form method="get" action="tablon.php" class="filtros">
    <label>Rango
        <select name="rango">
            <option value="">Todos</option>
            <?php foreach (RANGOS as $r): ?>
                <option value="<?= e($r) ?>" <?= $rango === $r ? 'selected' : '' ?>>
                    <?= e($r) ?> · <?= e(etiquetaRango($r)) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Oro mínimo
        <input type="number" name="oro" min="0" max="10000" step="1" value="<?= $oroMin ?>">
    </label>
    <button type="submit">Filtrar</button>
    <a href="tablon.php">Quitar filtros</a>
</form>

<p><?= count($visibles) ?> misión(es) mostrada(s).</p>

<section class="tarjetas">
<?php foreach ($visibles as $m): ?>
    <article class="tarjeta <?= e(claseRango($m['rango'])) ?>">
        <h3><?= e($m['titulo']) ?></h3>
        <p class="rango">Rango <?= e($m['rango']) ?> · <?= e(etiquetaRango($m['rango'])) ?></p>
        <p><?= e($m['descripcion']) ?></p>
        <p class="detalle">
            <span><?= e(formatearOro($m['oro'])) ?></span>
            <span><?= e(formatearDias($m['dias'])) ?></span>
        </p>
        <?php if (in_array($m['id'], $enZurron, true)): ?>
            <p class="en-zurron">✔ En tu zurrón</p>
        <?php else: ?>
            <form method="post" action="tablon.php">
                <input type="hidden" name="accion" value="aceptar">
                <input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
                <input type="hidden" name="rango" value="<?= e($rango ?? '') ?>">
                <input type="hidden" name="oro" value="<?= $oroMin ?>">
                <button type="submit">Aceptar misión</button>
            </form>
        <?php endif; ?>
    </article>
<?php endforeach; ?>
</section>
<?php require __DIR__ . '/inc/pie.php'; ?>
