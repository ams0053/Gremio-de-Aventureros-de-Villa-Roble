<?php
declare(strict_types=1);
require __DIR__ . '/inc/sesion.php';
require __DIR__ . '/inc/funciones.php';
require __DIR__ . '/inc/datos_misiones.php';

requiereLogin();
$misiones = obtenerMisiones();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'abandonar') {
    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
    $mision = $id === false ? null : buscarMision($misiones, $id);
    $zurron = $_SESSION['zurron'] ?? [];

    if ($mision === null || !in_array($mision['id'], $zurron, true)) {
        flash('Esa misión no está en tu zurrón.', 'error');
    } else {
        $_SESSION['zurron'] = array_values(array_diff($zurron, [$mision['id']]));
        flash('Has abandonado «' . $mision['titulo'] . '».', 'aviso');
    }
    header('Location: zurron.php');
    exit;
}

$ids = $_SESSION['zurron'] ?? [];
$aceptadas = [];
foreach ($ids as $id) {
    $m = buscarMision($misiones, (int) $id);
    if ($m !== null) {
        $aceptadas[] = $m;
    }
}

$titulo = 'Zurrón';
require __DIR__ . '/inc/cabecera.php';
?>
<h2>Tu zurrón</h2>
<?php if (!$aceptadas): ?>
    <p>Todavía no has aceptado ninguna misión. <a href="tablon.php">Ir al tablón</a></p>
<?php else: ?>
<table class="tabla">
    <thead><tr><th>Misión</th><th>Rango</th><th>Recompensa</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($aceptadas as $m): ?>
        <tr>
            <td><?= e($m['titulo']) ?></td>
            <td><?= e($m['rango']) ?> · <?= e(etiquetaRango($m['rango'])) ?></td>
            <td><?= e(formatearOro($m['oro'])) ?></td>
            <td>
                <form method="post" action="zurron.php">
                    <input type="hidden" name="accion" value="abandonar">
                    <input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
                    <button type="submit">Abandonar</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
        <tr><th colspan="2">Recompensa total</th><th colspan="2"><?= e(formatearOro(totalRecompensa($ids, $misiones))) ?></th></tr>
    </tfoot>
</table>
<?php endif; ?>
<?php require __DIR__ . '/inc/pie.php'; ?>
