<?php
header('Location: tablon.php');
exit;
