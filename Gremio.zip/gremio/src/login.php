<?php
declare(strict_types=1);
require __DIR__ . '/inc/sesion.php';
require __DIR__ . '/inc/funciones.php';
require __DIR__ . '/inc/conexion.php';

if (aventureroActual() !== null) {
    header('Location: tablon.php');
    exit;
}

$error = '';
$usuarioForm = usuarioRecordado();
$recordar = $usuarioForm !== '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario  = trim((string) ($_POST['usuario'] ?? ''));
    $clave    = (string) ($_POST['clave'] ?? '');
    $recordar = isset($_POST['recordar']);
    $usuarioForm = $usuario;

    if ($usuario === '' || $clave === '') {
        $error = 'Rellena usuario y contraseña.';
    } else {
        try {
            $aventurero = autenticar(conectar(), $usuario, $clave);
        } catch (PDOException $ex) {
            error_log('Gremio login: ' . $ex->getMessage());
            $aventurero = null;
            $error = 'No se pudo iniciar sesión. Inténtalo más tarde.';
        }

        if ($aventurero !== null) {
            session_regenerate_id(true);
            $_SESSION['aventurero']  = $aventurero;
            $_SESSION['zurron']      = [];
            $_SESSION['visitas']     = 0;
            $_SESSION['hora_entrada'] = date('H:i:s');

            if ($recordar) {
                recordarUsuario($aventurero['usuario']);
            } else {
                olvidarUsuario();
            }
            flash('Bienvenido al gremio, ' . $aventurero['nombre'] . '.', 'ok');
            header('Location: tablon.php');
            exit;
        }
        if ($error === '') {
            $error = 'Usuario o contraseña incorrectos.';
        }
    }
}

$aviso = match ($_GET['motivo'] ?? '') {
    'privado' => 'Esta página es solo para miembros del gremio.',
    'salio'   => 'Has cerrado sesión. ¡Buen viaje!',
    default   => '',
};

$titulo = 'Entrar';
require __DIR__ . '/inc/cabecera.php';
?>
<h2>Entrar al gremio</h2>
<?php if ($aviso !== ''): ?><p class="flash info"><?= e($aviso) ?></p><?php endif; ?>
<?php if ($error !== ''): ?><p class="flash error"><?= e($error) ?></p><?php endif; ?>

<form method="post" action="login.php" class="formulario">
    <label>Usuario
        <input type="text" name="usuario" value="<?= e($usuarioForm) ?>" maxlength="30" required autofocus>
    </label>
    <label>Contraseña
        <input type="password" name="clave" required>
    </label>
    <label class="check">
        <input type="checkbox" name="recordar" <?= $recordar ? 'checked' : '' ?>> Recordar mi usuario
    </label>
    <button type="submit">Entrar</button>
</form>
<?php require __DIR__ . '/inc/pie.php'; ?>
